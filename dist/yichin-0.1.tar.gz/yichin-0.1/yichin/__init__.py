from yichin import encode, decode

__version__ = '0.1'
